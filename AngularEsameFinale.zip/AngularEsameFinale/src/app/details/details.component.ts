import { Component, OnInit } from '@angular/core';
import { FooterComponent } from '../footer/footer.component';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {
  
  data =
    {
      "idAttrazione": 0,
      "nome": "Colosseo",
      "descrizioneCorta": "Descrizione del colosseo",
      "descrizioneCompleta": "Descrizione completa del colosseo, storia opere ecc.",
      "localita": "Roma",
      "tipoInteresse": "Storico, Paesaggistico",
      "immagine": "https://upload.wikimedia.org/wikipedia/commons/thumb/d/de/Colosseo_2020.jpg/1200px-Colosseo_2020.jpg"
    }

  constructor() { }

  ngOnInit(): void {
  }

}
