import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { DetailsComponent } from './details/details.component';
import { PassComponent } from './pass/pass.component';

const routes: Routes = [
  { path: '', component: HomeComponent},
  { path: 'details/:idAttrazione', component: DetailsComponent},
  { path: 'pass', component: PassComponent},
  { path: '**', redirectTo: ''}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
