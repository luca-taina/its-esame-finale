import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ServiceApiService {

  data = [
    {
      "idAttrazione": 0,
      "nome": "Colosseo",
      "descrizioneCorta": "Descrizione del colosseo",
      "descrizioneCompleta": "Descrizione completa del colosseo, storia opere ecc.",
      "localita": "Roma",
      "tipoInteresse": "Storico, Paesaggistico",
      "immagine": "https://upload.wikimedia.org/wikipedia/commons/thumb/d/de/Colosseo_2020.jpg/1200px-Colosseo_2020.jpg"
    },
    {
      "idAttrazione": 1,
      "nome": "Piazza San Marco",
      "descrizioneCorta": "Descrizione della Piazza di San Marco",
      "descrizioneCompleta": "Descrizione completa della Piazza di San Marco , perchè è la più bella di Venezia",
      "localita": "Venezia",
      "tipoInteresse": "Storico, Paesaggistico",
      "immagine": "https://cdn.marcopolo.tv/960x480/media/post/5lplbv5/piazza-san-marco2.jpg"
    },
    {
      "idAttrazione": 2,
      "nome": "Galleria degli Uffizi",
      "descrizioneCorta": "Descrizione della galleria",
      "descrizioneCompleta": "Descrizione completa della galleria, perchè è la più bella di Firenze",
      "localita": "Firenze",
      "tipoInteresse": "Artistico, Storico",
      "immagine": "https://images.uffizi.it/production/attachments/1568618095066237-Madonna-della-Cesta-2-piccolo.jpg?ixlib=rails-2.1.3&w=700&h=fill&fit=unset&crop=center&fm=gjpg&auto=compress"
    },
    {
      "idAttrazione": 3,
      "nome": "Cinque Terre",
      "descrizioneCorta": "Descrizione delle Cinque Terre",
      "descrizioneCompleta": "Descrizione completa delle Cinque Terre, perchè sono le più belle del mondo",
      "localita": "Varie",
      "tipoInteresse": "Paesaggistico",
      "immagine": "https://www.incinqueterre.com/photo/photo_manarola1_b1.jpg"
    }
    
  ]
  
  constructor() { }
}
